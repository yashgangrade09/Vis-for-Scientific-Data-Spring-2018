array = 1:1:100;
disp(array)
boxplot(array)
ylabel("Values")
title('Boxplot of an array with 100 elements in order')
