To run the python files:

Part1.py - Contains all questions from the Part 1
Part2Q1.py - Question 1 of Part 2
Part2Q2_Star.py - Star Plot in Question 2 of part 2
Part2Q2_Parallel.py - Parallel Coordinates in Question 2 of Part 2
Part2Q3.py - Question 3 of part 2
Part2Q4.py - Question 4 of part 2

To run the Matlab files:

Part1Q1.m - Question 1 of Part 1
P1Q2.m - Question 2 of Part 1
P1Q3.m - Question 3 of Part 1
P1Q4.m - Question 4 of Part 1
P2Q1.m - Question 1 of Part 2
P2Q3.m - Question 3 of Part 2